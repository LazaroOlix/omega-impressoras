import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getOrders, updateOrderData, deleteOrder } from '../services/storage';
import { ServiceOrder, STATUS_COLORS, STATUS_LABELS } from '../types';
import { ArrowLeft, Send, CheckCircle, Package, ExternalLink, Wrench, PenTool, Trash2, Lock, Clock, PackageCheck, Printer as PrintIcon, Calendar } from 'lucide-react';

export const OSDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [order, setOrder] = useState<ServiceOrder | null>(null);
  
  const [budgetInput, setBudgetInput] = useState<string>('');
  const [serviceDesc, setServiceDesc] = useState<string>('');
  const [partsDesc, setPartsDesc] = useState<string>('');
  const [internalNotes, setInternalNotes] = useState<string>('');
  const [warranty, setWarranty] = useState<string>('90 dias');

  useEffect(() => {
    if (id) {
      const allOrders = getOrders();
      const found = allOrders.find(o => o.id === id);
      if (found) {
        setOrder(found);
        setBudgetInput(found.valorTotal.toString());
        setServiceDesc(found.descricaoServico || '');
        setPartsDesc(found.pecasTrocadas || '');
        setInternalNotes(found.observacoesInternas || '');
        setWarranty(found.garantia || '90 dias');
      } else {
        navigate('/lista-os');
      }
    }
  }, [id, navigate]);

  const handleSaveData = () => {
    if (order) {
      const val = parseFloat(budgetInput) || 0;
      const updated = updateOrderData(order.id, {
        valorTotal: val,
        descricaoServico: serviceDesc,
        pecasTrocadas: partsDesc,
        observacoesInternas: internalNotes,
        garantia: warranty
      }, "Dados técnicos salvos manualmente.");
      
      if (updated) {
        setOrder(updated);
        alert('Dados salvos com sucesso!');
      }
    }
  };

  const handleStatusChange = (status: any, notes?: string) => {
    if (order) {
      const acao = `Status alterado para ${STATUS_LABELS[status as keyof typeof STATUS_LABELS] || status}${notes ? ' ('+notes+')' : ''}`;
      const updated = updateOrderData(order.id, { status }, acao);
      if (updated) {
        setOrder(updated);
      }
    }
  };

  const handleDeliver = () => {
    if (!order) return;
    
    const valorFinal = parseFloat(budgetInput) || order.valorTotal;

    if (valorFinal <= 0) {
      alert("Atenção: É obrigatório informar o valor do serviço (R$) antes de realizar a entrega.");
      return;
    }

    // Diálogo de confirmação conforme solicitado
    if (!confirm(`Deseja confirmar a ENTREGA da OS ${order.id}? Valor: R$ ${valorFinal.toFixed(2)}?`)) {
      return;
    }

    try {
      // Atualização atômica para garantir persistência e faturamento
      const updated = updateOrderData(order.id, {
        status: "ENTREGUE",
        entregueEm: new Date().toISOString(),
        valorTotal: valorFinal,
        descricaoServico: serviceDesc,
        pecasTrocadas: partsDesc,
        observacoesInternas: internalNotes,
        garantia: warranty
      }, `Equipamento entregue ao cliente. Valor final: R$ ${valorFinal.toFixed(2)}`);

      if (updated) {
        alert("Ordem de serviço finalizada e entregue com sucesso!");
        navigate('/', { replace: true });
      } else {
        alert("Erro ao salvar os dados da entrega. Tente novamente.");
      }
    } catch (err) {
      console.error(err);
      alert("Ocorreu um erro inesperado ao processar a entrega.");
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleDelete = () => {
    if (!order) return;
    if (confirm(`ATENÇÃO: Deseja EXCLUIR permanentemente a OS ${order.id}?`)) {
      deleteOrder(order.id);
      navigate('/lista-os');
    }
  };

  if (!order) return <div className="p-12 text-center text-slate-400">Carregando detalhes...</div>;

  return (
    <>
      <div className="space-y-6 pb-20 print:hidden">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <button onClick={() => navigate('/lista-os')} className="p-2 hover:bg-slate-200 rounded-full transition-colors">
              <ArrowLeft className="w-6 h-6 text-slate-600" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-slate-800 flex items-center gap-3">
                {order.id} 
                <span className={`px-3 py-1 rounded-full text-sm font-bold ${STATUS_COLORS[order.status]}`}>
                  {STATUS_LABELS[order.status]}
                </span>
              </h1>
              <div className="flex items-center gap-4 text-xs mt-1 text-slate-500">
                <span className="flex items-center gap-1"><Calendar className="w-3 h-3"/> Entrada: {new Date(order.criadaEm).toLocaleDateString('pt-BR')}</span>
                <span className="flex items-center gap-1 text-red-500 font-bold"><Clock className="w-3 h-3"/> Limite: {new Date(order.dataLimite).toLocaleDateString('pt-BR')}</span>
              </div>
            </div>
          </div>
          
          <div className="flex gap-2">
            <button onClick={handlePrint} className="bg-white border border-slate-300 text-slate-700 px-4 py-2 rounded-lg flex items-center gap-2 font-bold hover:bg-slate-50 shadow-sm transition-all">
              <PrintIcon className="w-4 h-4" /> Imprimir
            </button>
            <button onClick={handleDelete} className="text-red-500 hover:text-red-700 px-4 py-2 rounded-lg flex items-center gap-1 text-sm font-bold hover:bg-red-50">
              <Trash2 className="w-4 h-4" /> Excluir
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            {/* Informações do Equipamento */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
              <h2 className="text-lg font-bold text-slate-800 mb-4 border-b pb-2 uppercase tracking-wide">Identificação</h2>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <p className="text-xs text-slate-400 uppercase font-black">Cliente</p>
                  <p className="text-slate-800 text-lg font-bold">{order.cliente.nome}</p>
                  <p className="text-slate-500 font-medium">{order.cliente.whatsapp}</p>
                </div>
                <div>
                  <p className="text-xs text-slate-400 uppercase font-black">Equipamento</p>
                  <p className="text-slate-800 text-lg font-bold">{order.impressora.modelo}</p>
                  <p className="text-slate-500 font-medium">S/N: {order.impressora.serie || 'Não informado'}</p>
                </div>
                <div className="col-span-2">
                  <p className="text-xs text-slate-400 uppercase font-black mb-1">Itens de Checklist</p>
                  <div className="flex flex-wrap gap-2">
                    {order.acessorios?.length ? order.acessorios.map(a => (
                      <span key={a} className="bg-blue-50 text-blue-700 px-3 py-1 rounded-lg text-xs font-bold border border-blue-100">{a}</span>
                    )) : <span className="text-slate-400 text-xs italic">Nenhum acessório registrado.</span>}
                  </div>
                </div>
                <div className="col-span-2">
                  <p className="text-xs text-slate-400 uppercase font-black">Defeito Informado</p>
                  <div className="mt-1 bg-slate-50 p-3 rounded-lg border border-slate-100 text-slate-700 text-sm italic">
                    "{order.defeito}"
                  </div>
                </div>
              </div>
            </div>

            {/* Laudo e Orçamento */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
              <h2 className="text-lg font-bold text-slate-800 mb-4 border-b pb-2 flex items-center gap-2 uppercase tracking-wide">
                <Wrench className="w-5 h-5 text-blue-500" /> Laudo e Orçamento
              </h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-bold text-slate-600 mb-1">Serviço Realizado</label>
                  <textarea 
                    className="w-full p-3 border border-slate-300 rounded-lg outline-none focus:ring-1 focus:ring-blue-500 text-sm" 
                    rows={3} 
                    value={serviceDesc} 
                    onChange={e => setServiceDesc(e.target.value)} 
                    disabled={order.status === 'ENTREGUE'}
                    placeholder="O que foi feito no equipamento?"
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-bold text-slate-600 mb-1">Peças Trocadas</label>
                    <textarea 
                      className="w-full p-3 border border-slate-300 rounded-lg outline-none focus:ring-1 focus:ring-blue-500 text-sm" 
                      rows={2} 
                      value={partsDesc} 
                      onChange={e => setPartsDesc(e.target.value)} 
                      disabled={order.status === 'ENTREGUE'}
                      placeholder="Quais peças foram substituídas?"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-600 mb-1">Notas Internas</label>
                    <textarea 
                      className="w-full p-3 border border-slate-300 rounded-lg outline-none bg-yellow-50 focus:ring-1 focus:ring-yellow-500 text-sm" 
                      rows={2} 
                      value={internalNotes} 
                      onChange={e => setInternalNotes(e.target.value)} 
                      disabled={order.status === 'ENTREGUE'}
                      placeholder="Somente para a oficina..."
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-end">
                  <div>
                    <label className="block text-sm font-bold text-slate-600 mb-1">Garantia</label>
                    <select className="w-full p-3 border border-slate-300 rounded-lg outline-none bg-white focus:ring-1 focus:ring-blue-500" value={warranty} onChange={e => setWarranty(e.target.value)} disabled={order.status === 'ENTREGUE'}>
                      <option value="30 dias">30 dias</option>
                      <option value="60 dias">60 dias</option>
                      <option value="90 dias">90 dias</option>
                      <option value="Sem garantia">Sem garantia</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-600 mb-1">Valor Total (R$)</label>
                    <input type="number" step="0.01" className="w-full p-3 border border-slate-300 rounded-lg text-xl font-bold text-blue-700 focus:ring-1 focus:ring-blue-500" value={budgetInput} onChange={e => setBudgetInput(e.target.value)} disabled={order.status === 'ENTREGUE'} />
                  </div>
                </div>
                {order.status !== 'ENTREGUE' && (
                  <div className="flex justify-end pt-2">
                    <button onClick={handleSaveData} className="text-sm font-bold text-blue-600 flex items-center gap-1 hover:bg-blue-50 p-2 rounded transition-colors">
                      <PenTool className="w-4 h-4" /> Salvar Orçamento
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
              <h2 className="text-lg font-bold text-slate-800 mb-4 uppercase">Status</h2>
              <div className="space-y-3">
                {order.status !== 'ENTREGUE' && (
                   <>
                    {(order.status === 'RECEBIDA' || order.status === 'ORCAMENTO') && (
                      <button onClick={() => handleStatusChange('MANUTENCAO')} className="w-full py-3 bg-purple-600 text-white rounded-lg font-bold hover:bg-purple-700 transition-colors shadow-sm uppercase text-sm">Iniciar Manutenção</button>
                    )}
                    {order.status === 'MANUTENCAO' && (
                      <button onClick={() => handleStatusChange('PRONTA')} className="w-full py-3 bg-green-600 text-white rounded-lg font-bold hover:bg-green-700 transition-colors shadow-sm uppercase text-sm">Equipamento Pronto</button>
                    )}
                    {(order.status === 'PRONTA' || order.status === 'MANUTENCAO') && (
                      <button onClick={handleDeliver} className="w-full py-5 bg-slate-900 text-white rounded-lg font-black text-xl hover:bg-slate-800 transition-all shadow-xl active:scale-95 border-b-4 border-slate-700 mt-4">
                        ENTREGAR
                      </button>
                    )}
                   </>
                )}
                
                {order.status === 'ENTREGUE' && (
                   <div className="bg-emerald-50 border-2 border-emerald-200 p-6 rounded-lg text-emerald-800 text-center flex flex-col items-center gap-2">
                      <CheckCircle className="w-10 h-10" />
                      <p className="font-black text-lg">ENTREGUE</p>
                      <p className="text-xs font-bold uppercase">{new Date(order.entregueEm!).toLocaleString('pt-BR')}</p>
                   </div>
                )}
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
               <h2 className="text-sm font-black text-slate-400 uppercase tracking-widest mb-4 border-b pb-2">Linha do Tempo</h2>
               <div className="space-y-4 max-h-64 overflow-y-auto pr-2 custom-scroll">
                  {order.historico.slice().reverse().map((h, i) => (
                    <div key={i} className="border-l-2 border-slate-200 pl-4 py-1 relative">
                      <div className="absolute -left-[5px] top-2 w-2 h-2 rounded-full bg-slate-300"></div>
                      <p className="text-xs text-slate-800 font-bold leading-tight">{h.acao}</p>
                      <p className="text-[10px] text-slate-400 font-medium">{new Date(h.data).toLocaleString('pt-BR')}</p>
                    </div>
                  ))}
               </div>
            </div>
          </div>
        </div>
      </div>

      {/* Print Layout */}
      <div className="hidden print:block bg-white p-10 font-sans text-black">
         <div className="flex justify-between items-start border-b-4 border-black pb-8 mb-8">
            <div>
               <h1 className="text-4xl font-black">OMEGA OS</h1>
               <p className="font-bold text-slate-600 uppercase">Reparo de Impressoras Profissional</p>
               <p className="text-sm font-bold mt-1">(16) 3333-7608</p>
            </div>
            <div className="text-right">
               <p className="text-sm font-black bg-black text-white px-2 py-1 mb-1 inline-block">ORDEM DE SERVIÇO</p>
               <h2 className="text-4xl font-black">#{order.id}</h2>
               <p className="text-xs font-bold mt-2 uppercase">Entrada: {new Date(order.criadaEm).toLocaleString('pt-BR')}</p>
               {order.entregueEm && <p className="text-xs font-bold uppercase">Saída: {new Date(order.entregueEm).toLocaleString('pt-BR')}</p>}
            </div>
         </div>

         <div className="grid grid-cols-2 gap-10 mb-8 border-b-2 border-slate-100 pb-8">
            <div className="space-y-1">
               <h3 className="text-xs font-black uppercase text-slate-400">Cliente</h3>
               <p className="text-xl font-bold">{order.cliente.nome}</p>
               <p className="text-sm font-medium">WhatsApp: {order.cliente.whatsapp}</p>
            </div>
            <div className="space-y-1">
               <h3 className="text-xs font-black uppercase text-slate-400">Equipamento</h3>
               <p className="text-xl font-bold">{order.impressora.modelo}</p>
               <p className="text-sm font-medium">S/N: {order.impressora.serie || 'N/A'}</p>
            </div>
         </div>

         <div className="mb-8 p-4 border border-slate-200 rounded">
            <h3 className="text-xs font-black uppercase text-slate-400 mb-2">Checklist / Acessórios</h3>
            <p className="text-sm font-bold">{order.acessorios?.join(' | ') || 'Equipamento básico.'}</p>
         </div>

         <div className="space-y-6 mb-12">
            <div className="p-4 bg-slate-50 border-l-4 border-slate-300 rounded">
               <h3 className="text-xs font-black uppercase text-slate-500 mb-2">Problema Relatado</h3>
               <p className="text-sm font-medium italic text-slate-700">"{order.defeito}"</p>
            </div>
            <div className="p-5 border-2 border-black rounded min-h-[120px]">
               <h3 className="text-xs font-black uppercase text-slate-400 mb-3">Laudo Técnico / Serviço Efetuado</h3>
               <p className="text-base font-bold leading-relaxed whitespace-pre-wrap">{order.descricaoServico || 'Relatório pendente.'}</p>
            </div>
            <div className="p-4 border border-slate-300 rounded">
               <h3 className="text-xs font-black uppercase text-slate-400 mb-2">Peças Trocadas</h3>
               <p className="text-sm font-bold">{order.pecasTrocadas || 'Nenhuma peça substituída.'}</p>
            </div>
         </div>

         <div className="flex justify-between items-end border-t-4 border-black pt-8">
            <div>
               <p className="text-xs font-black uppercase text-slate-400">Garantia</p>
               <p className="text-2xl font-black">{order.garantia || '90 dias'}</p>
               <p className="text-[10px] mt-2 font-bold uppercase text-slate-400 italic">Garantia válida mediante selo intacto.</p>
            </div>
            <div className="text-right">
               <p className="text-base font-black uppercase mb-1">Total Geral</p>
               <p className="text-5xl font-black">
                  {order.valorTotal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
               </p>
            </div>
         </div>

         <div className="mt-24 grid grid-cols-2 gap-24 px-10">
            <div className="border-t border-black text-center pt-2">
               <p className="text-[10px] font-black uppercase">Responsável Técnico</p>
            </div>
            <div className="border-t border-black text-center pt-2">
               <p className="text-[10px] font-black uppercase">Assinatura do Cliente</p>
            </div>
         </div>
      </div>
    </>
  );
};