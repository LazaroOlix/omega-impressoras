import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createOrder } from '../services/storage';
import { Save, User, Printer, AlertCircle, PackageCheck, Calendar } from 'lucide-react';

const ACESSORIOS_OPTIONS = [
  "Bandeja",
  "Toner / Cartucho",
  "Fonte",
  "Cabo de energia",
  "Cabo USB"
];

export const NewOS: React.FC = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    nome: '',
    whatsapp: '',
    modelo: '',
    serie: '',
    defeito: '',
    prazo: '3'
  });
  const [selectedAcessorios, setSelectedAcessorios] = useState<string[]>([]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.nome || !formData.modelo || !formData.defeito) return;

    createOrder(
      { nome: formData.nome, whatsapp: formData.whatsapp },
      { modelo: formData.modelo, serie: formData.serie },
      formData.defeito,
      selectedAcessorios,
      parseInt(formData.prazo, 10)
    );

    navigate('/lista-os');
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const toggleAcessorio = (item: string) => {
    setSelectedAcessorios(prev => 
      prev.includes(item) 
        ? prev.filter(i => i !== item)
        : [...prev, item]
    );
  };

  return (
    <div className="max-w-2xl mx-auto pb-10 print:hidden">
      <h1 className="text-3xl font-bold text-slate-800 mb-8">Nova Ordem de Serviço</h1>
      
      <form onSubmit={handleSubmit} className="bg-white p-8 rounded-xl shadow-sm border border-slate-200 space-y-8">
        
        {/* Cliente */}
        <div className="space-y-4">
          <div className="flex items-center space-x-2 text-slate-800 font-semibold border-b pb-2">
            <User className="w-5 h-5 text-blue-500" />
            <h3>Dados do Cliente</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Nome Completo *</label>
              <input
                required
                name="nome"
                value={formData.nome}
                onChange={handleChange}
                className="w-full p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                placeholder="Ex: João da Silva"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">WhatsApp</label>
              <input
                name="whatsapp"
                value={formData.whatsapp}
                onChange={handleChange}
                className="w-full p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                placeholder="Ex: 16999999999"
              />
            </div>
          </div>
        </div>

        {/* Impressora & Prazo */}
        <div className="space-y-4">
          <div className="flex items-center space-x-2 text-slate-800 font-semibold border-b pb-2">
            <Printer className="w-5 h-5 text-blue-500" />
            <h3>Dados do Equipamento</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-700 mb-1">Modelo da Impressora *</label>
              <input
                required
                name="modelo"
                value={formData.modelo}
                onChange={handleChange}
                className="w-full p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                placeholder="Ex: HP LaserJet 1020"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Nº de Série</label>
              <input
                name="serie"
                value={formData.serie}
                onChange={handleChange}
                className="w-full p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                placeholder="S/N"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1 flex items-center gap-1">
                <Calendar className="w-4 h-4" /> Prazo (Dias)
              </label>
              <input
                type="number"
                name="prazo"
                value={formData.prazo}
                onChange={handleChange}
                className="w-full p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
          </div>
        </div>

        {/* Acessórios */}
        <div className="space-y-4">
          <div className="flex items-center space-x-2 text-slate-800 font-semibold border-b pb-2">
            <PackageCheck className="w-5 h-5 text-blue-500" />
            <h3>Checklist de Itens Recebidos</h3>
          </div>
          <div className="grid grid-cols-2 gap-3">
             {ACESSORIOS_OPTIONS.map(item => (
               <label key={item} className="flex items-center space-x-2 p-2 rounded hover:bg-slate-50 cursor-pointer border border-transparent hover:border-slate-200">
                 <input 
                   type="checkbox"
                   checked={selectedAcessorios.includes(item)}
                   onChange={() => toggleAcessorio(item)}
                   className="w-4 h-4 text-blue-600 rounded"
                 />
                 <span className="text-slate-700 text-sm">{item}</span>
               </label>
             ))}
          </div>
        </div>

        {/* Defeito */}
        <div className="space-y-4">
          <div className="flex items-center space-x-2 text-slate-800 font-semibold border-b pb-2">
            <AlertCircle className="w-5 h-5 text-blue-500" />
            <h3>Relato do Defeito</h3>
          </div>
          <div>
            <textarea
              required
              name="defeito"
              value={formData.defeito}
              onChange={handleChange}
              rows={3}
              className="w-full p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              placeholder="Descreva o problema relatado..."
            />
          </div>
        </div>

        <button
          type="submit"
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-xl flex items-center justify-center space-x-2 transition-all shadow-md active:scale-95"
        >
          <Save className="w-5 h-5" />
          <span>Cadastrar OS</span>
        </button>
      </form>
    </div>
  );
};