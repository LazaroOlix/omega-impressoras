import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { LayoutDashboard, PlusCircle, List, Printer, LogOut } from 'lucide-react';
import { logout } from '../services/auth';

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path 
    ? "bg-slate-800 text-white" 
    : "text-slate-400 hover:bg-slate-800 hover:text-white";

  const handleLogout = () => {
    if (confirm("Deseja realmente sair?")) {
      logout();
      window.location.reload();
    }
  };

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 bg-slate-900 text-white flex flex-col fixed h-full print:hidden">
        <div className="p-6 flex items-center space-x-3 border-b border-slate-700">
          <Printer className="w-8 h-8 text-blue-400" />
          <span className="text-xl font-bold tracking-wider">OMEGA OS</span>
        </div>
        
        <nav className="flex-1 p-4 space-y-2">
          <Link to="/" className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${isActive('/')}`}>
            <LayoutDashboard className="w-5 h-5" />
            <span>Dashboard</span>
          </Link>
          
          <Link to="/nova-os" className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${isActive('/nova-os')}`}>
            <PlusCircle className="w-5 h-5" />
            <span>Nova OS</span>
          </Link>

          <Link to="/lista-os" className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${isActive('/lista-os')}`}>
            <List className="w-5 h-5" />
            <span>Consultar OS</span>
          </Link>
        </nav>

        <div className="p-4 space-y-2">
          <button 
            onClick={handleLogout}
            className="w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-red-400 hover:bg-red-500/10 transition-colors"
          >
            <LogOut className="w-5 h-5" />
            <span>Sair</span>
          </button>
          <div className="border-t border-slate-800 pt-2 text-center text-xs text-slate-500">
            Omega OS v1.2<br/>Assistência Técnica
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 ml-64 overflow-auto print:m-0 print:bg-white print:overflow-visible">
        <div className="p-8 max-w-7xl mx-auto print:p-0">
          {children}
        </div>
      </main>
    </div>
  );
};