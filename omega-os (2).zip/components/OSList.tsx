import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getOrders } from '../services/storage';
import { ServiceOrder, STATUS_COLORS, STATUS_LABELS, OSStatus } from '../types';
import { Search, ChevronRight, MessageCircle, Clock, AlertCircle } from 'lucide-react';

export const OSList: React.FC = () => {
  const [orders, setOrders] = useState<ServiceOrder[]>([]);
  const [filter, setFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState<OSStatus | 'TODOS'>('TODOS');

  useEffect(() => {
    const load = () => setOrders(getOrders().reverse());
    load();
    window.addEventListener('focus', load);
    return () => window.removeEventListener('focus', load);
  }, []);

  const filteredOrders = orders.filter(order => {
    const matchesText = 
      order.cliente.nome.toLowerCase().includes(filter.toLowerCase()) ||
      order.id.toLowerCase().includes(filter.toLowerCase()) ||
      order.impressora.modelo.toLowerCase().includes(filter.toLowerCase());
    const matchesStatus = statusFilter === 'TODOS' || order.status === statusFilter;
    return matchesText && matchesStatus;
  });

  const getDeadlineStatus = (order: ServiceOrder) => {
    if (order.status === 'ENTREGUE') return { label: 'Finalizado', color: 'text-slate-400', icon: null };
    
    const today = new Date();
    today.setHours(0,0,0,0);
    const limit = new Date(order.dataLimite);
    limit.setHours(0,0,0,0);

    const diff = limit.getTime() - today.getTime();
    if (diff < 0) return { label: 'Atrasado', color: 'text-red-600', icon: <AlertCircle className="w-4 h-4" /> };
    if (diff === 0) return { label: 'Hoje!', color: 'text-amber-600', icon: <Clock className="w-4 h-4" /> };
    return { label: `Dentro`, color: 'text-green-600', icon: null };
  };

  return (
    <div className="space-y-6 print:hidden">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <h1 className="text-3xl font-bold text-slate-800">Ordens de Serviço</h1>
        <div className="flex gap-4 w-full md:w-auto">
          <div className="relative flex-1 md:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Buscar..." 
              className="w-full pl-10 pr-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-blue-500 outline-none"
              value={filter}
              onChange={e => setFilter(e.target.value)}
            />
          </div>
          <select 
            className="px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
          >
            <option value="TODOS">Todos</option>
            {Object.keys(STATUS_LABELS).map(key => (
              <option key={key} value={key}>{STATUS_LABELS[key as OSStatus]}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead className="bg-slate-50 border-b border-slate-200">
            <tr>
              <th className="p-4 font-semibold text-slate-600 text-sm">OS / Equipamento</th>
              <th className="p-4 font-semibold text-slate-600 text-sm">Cliente</th>
              <th className="p-4 font-semibold text-slate-600 text-sm text-center">Status</th>
              <th className="p-4 font-semibold text-slate-600 text-sm text-center">Prazo</th>
              <th className="p-4 font-semibold text-slate-600 text-sm text-right">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredOrders.length === 0 ? (
              <tr><td colSpan={5} className="p-8 text-center text-slate-400 italic">Nenhuma OS encontrada.</td></tr>
            ) : (
              filteredOrders.map(order => {
                const dl = getDeadlineStatus(order);
                return (
                  <tr key={order.id} className="hover:bg-slate-50 transition-colors">
                    <td className="p-4">
                      <div className="font-bold text-slate-900">{order.id}</div>
                      <div className="text-xs text-slate-500 truncate max-w-[150px]">{order.impressora.modelo}</div>
                    </td>
                    <td className="p-4">
                      <div className="text-slate-700 font-medium">{order.cliente.nome}</div>
                      <div className="text-xs text-slate-400">{order.cliente.whatsapp}</div>
                    </td>
                    <td className="p-4 text-center">
                      <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${STATUS_COLORS[order.status]}`}>
                        {STATUS_LABELS[order.status]}
                      </span>
                    </td>
                    <td className="p-4 text-center">
                      <div className={`flex items-center justify-center gap-1 text-xs font-bold ${dl.color}`}>
                        {dl.icon}
                        {dl.label}
                      </div>
                      <div className="text-[10px] text-slate-400">{new Date(order.dataLimite).toLocaleDateString('pt-BR')}</div>
                    </td>
                    <td className="p-4 flex items-center justify-end gap-1">
                      <Link to={`/os/${order.id}`} className="p-2 text-blue-600 hover:bg-blue-100 rounded-lg transition-colors">
                        <ChevronRight className="w-5 h-5" />
                      </Link>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};