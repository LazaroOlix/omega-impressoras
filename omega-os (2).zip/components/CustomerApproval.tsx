import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { getOrders, updateOrderStatus } from '../services/storage';
import { ServiceOrder } from '../types';
import { Check, X, Printer, AlertTriangle } from 'lucide-react';

export const CustomerApproval: React.FC = () => {
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token');
  const [order, setOrder] = useState<ServiceOrder | null>(null);
  const [actionTaken, setActionTaken] = useState<boolean>(false);

  useEffect(() => {
    if (token) {
      const allOrders = getOrders();
      const found = allOrders.find(o => o.token === token);
      if (found) {
        setOrder(found);
      }
    }
  }, [token]);

  const handleApprove = () => {
    if (order) {
      updateOrderStatus(order.id, 'MANUTENCAO', 'Aprovado pelo Cliente via Link');
      setOrder(prev => prev ? ({...prev, status: 'MANUTENCAO'}) : null);
      setActionTaken(true);
    }
  };

  const handleReject = () => {
    if (order) {
      updateOrderStatus(order.id, 'RECUSADO', 'Recusado pelo Cliente via Link');
      setOrder(prev => prev ? ({...prev, status: 'RECUSADO'}) : null);
      setActionTaken(true);
    }
  };

  if (!token) return <div className="p-8 text-center text-slate-500">Link inválido.</div>;
  if (!order) return <div className="p-8 text-center text-slate-500">Ordem de serviço não encontrada.</div>;

  if (actionTaken || (order.status !== 'AGUARDANDO_APROVACAO' && order.status !== 'ORCAMENTO')) {
     return (
        <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6">
           <div className="bg-white p-8 rounded-2xl shadow-lg w-full max-w-md text-center">
             <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Check className="w-8 h-8 text-blue-600" />
             </div>
             <h1 className="text-2xl font-bold text-slate-800 mb-2">Obrigado!</h1>
             <p className="text-slate-600">Sua resposta foi registrada com sucesso.</p>
             <div className="mt-6 p-4 bg-slate-50 rounded-lg text-sm text-slate-500">
               Status atual: <span className="font-bold text-slate-800">{order.status}</span>
             </div>
           </div>
        </div>
     );
  }

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-xl overflow-hidden">
        <div className="bg-slate-900 p-6 text-center">
          <h1 className="text-white text-xl font-bold tracking-wider">OMEGA OS</h1>
          <p className="text-slate-400 text-sm mt-1">Aprovação de Orçamento</p>
        </div>

        <div className="p-6 space-y-6">
          <div className="text-center">
             <h2 className="text-lg font-medium text-slate-600">Olá, <span className="text-slate-900 font-bold">{order.cliente.nome}</span></h2>
             <p className="text-sm text-slate-500">Temos um orçamento para sua impressora.</p>
          </div>

          <div className="space-y-4">
            <div className="flex items-center space-x-3 p-3 bg-slate-50 rounded-lg">
              <Printer className="w-5 h-5 text-blue-500" />
              <div>
                <p className="text-xs text-slate-500 font-bold uppercase">Equipamento</p>
                <p className="text-slate-800 font-medium">{order.impressora.modelo}</p>
              </div>
            </div>

            <div className="flex items-start space-x-3 p-3 bg-slate-50 rounded-lg">
              <AlertTriangle className="w-5 h-5 text-orange-500 mt-1" />
              <div>
                <p className="text-xs text-slate-500 font-bold uppercase">Defeito</p>
                <p className="text-slate-800 text-sm">{order.defeito}</p>
              </div>
            </div>
          </div>

          <div className="text-center py-4 border-t border-b border-slate-100">
            <p className="text-slate-500 text-sm mb-1">Valor Total do Serviço</p>
            <p className="text-4xl font-bold text-slate-900">
              {order.valorTotal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
            </p>
          </div>

          <div className="space-y-3 pt-2">
            <button 
              onClick={handleApprove}
              className="w-full bg-green-600 active:bg-green-700 text-white py-4 rounded-xl font-bold text-lg shadow-lg flex items-center justify-center space-x-2 transition-transform active:scale-95"
            >
              <Check className="w-6 h-6" />
              <span>APROVAR ORÇAMENTO</span>
            </button>
            
            <button 
              onClick={handleReject}
              className="w-full bg-white border-2 border-slate-200 text-slate-600 py-3 rounded-xl font-bold flex items-center justify-center space-x-2 hover:bg-slate-50 transition-colors"
            >
              <X className="w-5 h-5" />
              <span>Recusar</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};