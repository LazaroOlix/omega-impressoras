import React, { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { getOrders, exportData, importData } from '../services/storage';
import { ServiceOrder, STATUS_LABELS } from '../types';
import { DollarSign, Printer, CheckCircle, Package, Database, Download, Upload, Clock, AlertTriangle } from 'lucide-react';
import { Link } from 'react-router-dom';

export const Dashboard: React.FC = () => {
  const [orders, setOrders] = useState<ServiceOrder[]>([]);

  const loadData = () => {
    const allOrders = getOrders();
    setOrders(allOrders);
  };

  useEffect(() => {
    loadData();
    window.addEventListener('focus', loadData);
    window.addEventListener('storage_updated', loadData);
    return () => {
      window.removeEventListener('focus', loadData);
      window.removeEventListener('storage_updated', loadData);
    };
  }, []);

  const statusCounts = orders.reduce((acc, order) => {
    acc[order.status] = (acc[order.status] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const chartData = Object.keys(STATUS_LABELS).map(key => ({
    name: STATUS_LABELS[key as keyof typeof STATUS_LABELS],
    rawKey: key,
    value: statusCounts[key] || 0
  })).filter(item => item.value > 0);

  const today = new Date();
  today.setHours(0,0,0,0);
  const todayStr = today.toISOString().split('T')[0];

  const totalOpen = orders.filter(o => o.status !== "ENTREGUE" && o.status !== "RECUSADO").length;
  const totalReady = statusCounts["PRONTA"] || 0;
  
  // Faturamento apenas de entregas realizadas hoje
  const deliveredTodayOrders = orders.filter(o => {
    if (o.status !== "ENTREGUE" || !o.entregueEm) return false;
    const dateStr = o.entregueEm.split('T')[0];
    return dateStr === todayStr;
  });

  const deliveredTodayCount = deliveredTodayOrders.length;
  const revenueToday = deliveredTodayOrders.reduce((sum, o) => sum + (Number(o.valorTotal) || 0), 0);

  // Deadline logic (OS em atraso)
  const delayed = orders.filter(o => {
    if (o.status === 'ENTREGUE' || o.status === 'RECUSADO') return false;
    const limit = new Date(o.dataLimite);
    limit.setHours(0,0,0,0);
    const now = new Date();
    now.setHours(0,0,0,0);
    return limit.getTime() < now.getTime();
  }).length;

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.[0]) return;
    if (!confirm("Restaurar backup substituirá todos os dados atuais. Prosseguir?")) return;
    const ok = await importData(e.target.files[0]);
    if (ok) {
      alert("Backup restaurado com sucesso!");
      loadData();
    } else {
      alert("Erro ao importar backup. Arquivo inválido.");
    }
  };

  return (
    <div className="space-y-6 print:hidden">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-black text-slate-800 tracking-tighter">Oficina Omega</h1>
        <div className="flex gap-2">
          <button onClick={exportData} title="Exportar Backup" className="flex items-center gap-2 bg-white border border-slate-300 text-slate-600 px-3 py-2 rounded-lg text-sm font-bold hover:bg-slate-50 transition-all shadow-sm">
            <Download className="w-4 h-4" /> Backup
          </button>
          <label className="flex items-center gap-2 bg-slate-800 text-white px-3 py-2 rounded-lg text-sm font-bold hover:bg-slate-700 cursor-pointer shadow-sm">
            <Upload className="w-4 h-4" /> Restaurar
            <input type="file" accept=".json" onChange={handleImport} className="hidden" />
          </label>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Link to="/lista-os" className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 hover:border-blue-400 transition-all group">
          <div className="flex justify-between items-start">
            <div><p className="text-xs font-black uppercase text-slate-400 tracking-widest">Em Aberto</p><h3 className="text-4xl font-black text-slate-800 mt-1">{totalOpen}</h3></div>
            <div className="p-2 bg-blue-100 rounded-lg group-hover:scale-110 transition-transform"><Printer className="w-6 h-6 text-blue-600" /></div>
          </div>
          {delayed > 0 && <p className="text-xs text-red-600 mt-3 font-black flex items-center gap-1 bg-red-50 p-1 px-2 rounded w-fit"><AlertTriangle className="w-3 h-3"/> {delayed} atrasada{delayed !== 1 ? 's' : ''}</p>}
        </Link>
        
        <Link to="/lista-os" className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 hover:border-green-400 transition-all group">
          <div className="flex justify-between items-start">
            <div><p className="text-xs font-black uppercase text-slate-400 tracking-widest">Aguard. Retirada</p><h3 className="text-4xl font-black text-slate-800 mt-1">{totalReady}</h3></div>
            <div className="p-2 bg-green-100 rounded-lg group-hover:scale-110 transition-transform"><CheckCircle className="w-6 h-6 text-green-600" /></div>
          </div>
          <p className="text-xs text-slate-400 mt-4 font-bold uppercase">Serviços Prontos</p>
        </Link>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
          <div className="flex justify-between items-start">
            <div><p className="text-xs font-black uppercase text-slate-400 tracking-widest">Saídas Hoje</p><h3 className="text-4xl font-black text-slate-800 mt-1">{deliveredTodayCount}</h3></div>
            <div className="p-2 bg-slate-100 rounded-lg"><Package className="w-6 h-6 text-slate-600" /></div>
          </div>
          <p className="text-xs text-slate-400 mt-4 font-bold uppercase">Equipamentos Entregues</p>
        </div>

        <div className="bg-emerald-600 p-6 rounded-xl shadow-xl text-white">
          <div className="flex justify-between items-start">
            <div><p className="text-xs font-black uppercase text-emerald-100 tracking-widest">Faturado Hoje</p><h3 className="text-2xl font-black mt-1">{revenueToday.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</h3></div>
            <div className="p-2 bg-emerald-500/50 rounded-lg"><DollarSign className="w-6 h-6 text-white" /></div>
          </div>
          <p className="text-[10px] text-emerald-100 mt-4 font-black uppercase">Considerando Entregas de Hoje</p>
        </div>
      </div>

      <div className="bg-white p-8 rounded-xl shadow-sm border border-slate-200">
        <h3 className="text-lg font-black text-slate-800 mb-8 flex items-center gap-2 uppercase tracking-tighter"><Database className="w-5 h-5 text-blue-500"/> Fluxo de Trabalho (Geral)</h3>
        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
              <XAxis dataKey="name" stroke="#94a3b8" fontSize={10} tickLine={false} axisLine={false} fontWeight="bold" />
              <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} axisLine={false} fontWeight="bold" />
              <Tooltip cursor={{fill: '#f8fafc'}} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)', fontWeight: 'bold' }} />
              <Bar dataKey="value" radius={[6, 6, 0, 0]}>
                {chartData.map((entry, index) => {
                  const colors: any = { RECEBIDA: "#94a3b8", ORCAMENTO: "#3b82f6", AGUARDANDO_APROVACAO: "#eab308", MANUTENCAO: "#a855f7", PRONTA: "#22c55e", ENTREGUE: "#1e293b", RECUSADO: "#ef4444" };
                  return <Cell key={`cell-${index}`} fill={colors[entry.rawKey] || "#cbd5e1"} />;
                })}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};