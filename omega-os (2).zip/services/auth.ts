const AUTH_KEY = "OMEGA_OS_AUTH";

export const login = (email: string, pass: string): boolean => {
  if (email === "admin@omega" && pass === "123456") {
    localStorage.setItem(AUTH_KEY, "true");
    return true;
  }
  return false;
};

export const logout = () => {
  localStorage.removeItem(AUTH_KEY);
};

export const isAuthenticated = (): boolean => {
  return localStorage.getItem(AUTH_KEY) === "true";
};