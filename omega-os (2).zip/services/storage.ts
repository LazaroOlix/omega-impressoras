import { ServiceOrder, OSStatus } from "../types";

const STORAGE_KEY = "OMEGA_OS_DB";

export const generateId = (orders: ServiceOrder[]): string => {
  if (orders.length === 0) return "OS-0001";
  const maxId = orders.reduce((max, order) => {
    const parts = order.id.split('-');
    if (parts.length === 2) {
      const num = parseInt(parts[1], 10);
      return !isNaN(num) && num > max ? num : max;
    }
    return max;
  }, 0);
  return `OS-${String(maxId + 1).padStart(4, "0")}`;
};

export const generateUUID = (): string => {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
};

export const getOrders = (): ServiceOrder[] => {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    const parsed = data ? JSON.parse(data) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    console.error("Erro ao carregar dados do localStorage:", e);
    return [];
  }
};

export const saveOrders = (orders: ServiceOrder[]): void => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(orders));
    // Dispara evento para outros componentes (se necessário)
    window.dispatchEvent(new Event('storage_updated'));
  } catch (e) {
    console.error("Erro ao salvar no localStorage:", e);
  }
};

export const saveOrder = (order: ServiceOrder): ServiceOrder[] => {
  const orders = getOrders();
  const index = orders.findIndex((o) => o.id === order.id);
  if (index >= 0) {
    orders[index] = order;
  } else {
    orders.push(order);
  }
  saveOrders(orders);
  return orders;
};

export const createOrder = (
  cliente: { nome: string; whatsapp: string },
  impressora: { modelo: string; serie: string },
  defeito: string,
  acessorios: string[] = [],
  prazoEstimado: number = 3
): ServiceOrder => {
  const orders = getOrders();
  const newId = generateId(orders);
  const criadaEm = new Date();
  
  const dataLimite = new Date(criadaEm);
  dataLimite.setDate(criadaEm.getDate() + prazoEstimado);

  const newOrder: ServiceOrder = {
    id: newId,
    token: generateUUID(),
    cliente,
    impressora,
    defeito,
    descricaoServico: "", 
    pecasTrocadas: "",    
    observacoesInternas: "",
    garantia: "90 dias",
    acessorios: acessorios,
    prazoEstimado,
    dataLimite: dataLimite.toISOString(),
    status: "RECEBIDA",
    valorTotal: 0,
    criadaEm: criadaEm.toISOString(),
    entregueEm: null,
    historico: [
      {
        data: criadaEm.toISOString(),
        acao: `OS criada. Prazo: ${prazoEstimado} dias (Até ${dataLimite.toLocaleDateString('pt-BR')}). Acessórios: ${acessorios.length > 0 ? acessorios.join(', ') : 'Nenhum'}`
      }
    ]
  };

  saveOrder(newOrder);
  return newOrder;
};

// Função única para atualizar múltiplos campos e garantir persistência
export const updateOrderData = (id: string, updates: Partial<ServiceOrder>, historyAction?: string): ServiceOrder | null => {
  const orders = getOrders();
  const index = orders.findIndex(o => o.id === id);
  if (index === -1) return null;

  const currentOrder = orders[index];
  const updatedOrder = { ...currentOrder, ...updates };

  if (historyAction) {
    updatedOrder.historico.push({
      data: new Date().toISOString(),
      acao: historyAction
    });
  }

  // Se o status mudou para ENTREGUE, garante que entregueEm esteja preenchido
  if (updates.status === "ENTREGUE" && !updatedOrder.entregueEm) {
    updatedOrder.entregueEm = new Date().toISOString();
  }

  orders[index] = updatedOrder;
  saveOrders(orders);
  return updatedOrder;
};

// Atalhos mantidos para compatibilidade, mas redirecionados para updateOrderData
export const updateOrderStatus = (id: string, newStatus: OSStatus, notes?: string): ServiceOrder | null => {
  let acao = `Status alterado para ${newStatus}`;
  if (notes) acao += ` (${notes})`;
  
  const updates: Partial<ServiceOrder> = { status: newStatus };
  if (newStatus === "ENTREGUE") {
    updates.entregueEm = new Date().toISOString();
  }
  
  return updateOrderData(id, updates, acao);
};

export const updateOrderBudget = (
  id: string, 
  value: number, 
  descricao: string, 
  pecas: string,
  observacoes?: string,
  garantia?: string
): ServiceOrder | null => {
  return updateOrderData(id, {
    valorTotal: value,
    descricaoServico: descricao,
    pecasTrocadas: pecas,
    observacoesInternas: observacoes,
    garantia: garantia
  }, `Dados técnicos atualizados. Valor: R$ ${value.toFixed(2)}`);
};

export const deleteOrder = (id: string): void => {
  const orders = getOrders();
  const filtered = orders.filter(o => o.id !== id);
  saveOrders(filtered);
};

export const exportData = () => {
  const data = localStorage.getItem(STORAGE_KEY);
  if (!data) return;
  const blob = new Blob([data], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `omega_os_backup_${new Date().toISOString().split('T')[0]}.json`;
  a.click();
  URL.revokeObjectURL(url);
};

export const importData = (file: File): Promise<boolean> => {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const json = JSON.parse(e.target?.result as string);
        if (Array.isArray(json)) {
          saveOrders(json);
          resolve(true);
        } else {
          resolve(false);
        }
      } catch (err) {
        resolve(false);
      }
    };
    reader.readAsText(file);
  });
};